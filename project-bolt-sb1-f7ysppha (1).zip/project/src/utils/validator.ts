interface ValidationResult {
  isValid: boolean;
  message: string;
}

export function validatePythonSolution(userCode: string, expectedOutput: string): ValidationResult {
  // Normalize both codes by removing extra whitespace and newlines
  const normalizedUser = userCode.trim().replace(/\s+/g, ' ');
  const normalizedExpected = expectedOutput.trim().replace(/\s+/g, ' ');

  // Check for exact match
  if (normalizedUser === normalizedExpected) {
    return {
      isValid: true,
      message: 'Correct! Your solution matches the expected output.',
    };
  }

  // Check for common mistakes
  if (!userCode.includes('[') && expectedOutput.includes('[')) {
    return {
      isValid: false,
      message: 'Hint: Try using list comprehension with square brackets []',
    };
  }

  if (userCode.includes('append') && !expectedOutput.includes('append')) {
    return {
      isValid: false,
      message: 'Hint: Instead of using append(), try using list comprehension',
    };
  }

  if (userCode.includes('for') && !userCode.includes('[') && expectedOutput.includes('[')) {
    return {
      isValid: false,
      message: 'Hint: Convert your for loop into a list comprehension',
    };
  }

  // Default feedback
  return {
    isValid: false,
    message: 'Not quite right. Check the expected output format and try again.',
  };
}