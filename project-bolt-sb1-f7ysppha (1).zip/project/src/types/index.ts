export interface OptimizationResult {
  code: string;
  changes: string[];
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  unlocked: boolean;
}

export interface Message {
  text: string;
  isBot: boolean;
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  initialCode: string;
  expectedOutput: string;
  points: number;
  completed: boolean;
}