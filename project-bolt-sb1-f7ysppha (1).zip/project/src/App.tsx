import React, { useState } from 'react';
import { Zap } from 'lucide-react';
import { CodeEditor } from './components/CodeEditor';
import { ExampleCode } from './components/ExampleCode';
import { ChatBot } from './components/ChatBot';
import { GameFeature } from './components/GameFeature';
import { CodeBlocksGame } from './components/CodeBlocksGame';
import { optimizePythonCode } from './utils/optimizer';
import { Button } from './components/ui/Button';
import type { OptimizationResult } from './types';

function App() {
  const [inputCode, setInputCode] = useState('');
  const [optimizedResult, setOptimizedResult] = useState<OptimizationResult | null>(null);

  const handleOptimize = () => {
    if (!inputCode.trim()) return;
    const result = optimizePythonCode(inputCode);
    setOptimizedResult(result);
  };

  return (
    <div className="min-h-screen bg-gray-900 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80')] bg-cover bg-fixed bg-center">
      <div className="min-h-screen backdrop-blur-sm backdrop-brightness-50">
        <header className="bg-gray-800/50 border-b border-gray-700">
          <div className="max-w-7xl mx-auto px-4 py-6">
            <div className="flex items-center gap-2">
              <Zap className="w-8 h-8 text-cyan-400" />
              <h1 className="text-2xl font-bold terminal-text">Code Adventure</h1>
            </div>
            <p className="mt-2 text-gray-400">
              Learn coding through fun games and challenges! 🚀
            </p>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <CodeBlocksGame />
              <GameFeature />
            </div>

            <div className="space-y-8">
              <ChatBot />
              <div className="game-card">
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <CodeEditor
                      code={inputCode}
                      onChange={setInputCode}
                      label="Your Code"
                    />
                    <Button
                      onClick={handleOptimize}
                      disabled={!inputCode.trim()}
                      className="mt-4"
                    >
                      Optimize Code
                    </Button>
                  </div>

                  {optimizedResult && (
                    <div>
                      <CodeEditor
                        code={optimizedResult.code}
                        onChange={() => {}}
                        label="Optimized Code"
                      />
                      {optimizedResult.changes.length > 0 && (
                        <div className="mt-4 bg-gray-800/50 p-4 rounded-lg border border-gray-700">
                          <h3 className="text-sm font-medium text-cyan-400 mb-2">
                            Optimizations Applied:
                          </h3>
                          <ul className="list-disc list-inside text-sm text-gray-300">
                            {optimizedResult.changes.map((change, index) => (
                              <li key={index}>{change}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;