import React from 'react';
import { Code2 } from 'lucide-react';

interface CodeEditorProps {
  code: string;
  onChange: (value: string) => void;
  label: string;
}

export function CodeEditor({ code, onChange, label }: CodeEditorProps) {
  return (
    <div className="w-full">
      <div className="flex items-center gap-2 mb-2">
        <Code2 className="w-5 h-5 text-cyan-400" />
        <label className="text-sm font-medium text-cyan-400">{label}</label>
      </div>
      <textarea
        value={code}
        onChange={(e) => onChange(e.target.value)}
        className="w-full h-[300px] p-4 font-mono text-sm bg-gray-800/50 border border-gray-700 
                   rounded-lg focus:ring-2 focus:ring-cyan-400 focus:border-transparent
                   text-gray-100 backdrop-blur-sm"
        placeholder="Enter your Python code here..."
      />
    </div>
  );
}