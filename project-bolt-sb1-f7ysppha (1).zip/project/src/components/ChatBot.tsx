import React, { useState } from 'react';
import { MessageSquare, Send } from 'lucide-react';
import { Message } from '../types';
import { PREDEFINED_QUESTIONS, BOT_RESPONSES } from '../constants/chatbot';
import { Button } from './ui/Button';

export function ChatBot() {
  const [messages, setMessages] = useState<Message[]>([
    { text: "Hi! I'm your Python optimization assistant. How can I help you?", isBot: true },
  ]);
  const [selectedQuestion, setSelectedQuestion] = useState('');

  const handleSendMessage = () => {
    if (!selectedQuestion) return;

    setMessages(prev => [...prev, 
      { text: selectedQuestion, isBot: false },
      { text: BOT_RESPONSES[selectedQuestion] || "I'm not sure about that. Try asking something else!", isBot: true }
    ]);
    setSelectedQuestion('');
  };

  return (
    <div className="bg-gray-800/50 rounded-lg p-4 backdrop-blur-sm border border-gray-700">
      <div className="flex items-center gap-2 mb-4">
        <MessageSquare className="w-5 h-5 text-cyan-400" />
        <h2 className="text-lg font-semibold text-cyan-400">Optimization Assistant</h2>
      </div>

      <div className="h-[300px] overflow-y-auto mb-4 space-y-4">
        {messages.map((msg, idx) => (
          <div key={idx} className={`chat-message ${msg.isBot ? 'bot' : 'user'}`}>
            {msg.text}
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <select
          value={selectedQuestion}
          onChange={(e) => setSelectedQuestion(e.target.value)}
          className="flex-1 bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-sm"
        >
          <option value="">Select a question...</option>
          {PREDEFINED_QUESTIONS.map((q) => (
            <option key={q} value={q}>{q}</option>
          ))}
        </select>
        <Button onClick={handleSendMessage} disabled={!selectedQuestion}>
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}