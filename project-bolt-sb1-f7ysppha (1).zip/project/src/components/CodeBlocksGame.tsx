import React, { useState } from 'react';
import { Puzzle, Trophy, Sparkles } from 'lucide-react';
import { Button } from './ui/Button';

interface CodeBlock {
  id: string;
  text: string;
  isCorrect: boolean;
}

const LEVELS = [
  {
    id: 'level1',
    title: 'Print Hello World',
    description: 'Help the robot print a greeting message!',
    blocks: [
      { id: 'print', text: 'print(', isCorrect: true },
      { id: 'message', text: '"Hello World"', isCorrect: true },
      { id: 'close', text: ')', isCorrect: true },
      { id: 'wrong1', text: 'console.log', isCorrect: false },
      { id: 'wrong2', text: 'hello_world', isCorrect: false },
    ],
    solution: ['print', 'message', 'close'],
  },
  {
    id: 'level2',
    title: 'Create a Variable',
    description: 'Help create a variable named "score" with value 100!',
    blocks: [
      { id: 'name', text: 'score', isCorrect: true },
      { id: 'equals', text: '=', isCorrect: true },
      { id: 'value', text: '100', isCorrect: true },
      { id: 'wrong1', text: 'var', isCorrect: false },
      { id: 'wrong2', text: ':=', isCorrect: false },
    ],
    solution: ['name', 'equals', 'value'],
  },
];

export function CodeBlocksGame() {
  const [currentLevel, setCurrentLevel] = useState(0);
  const [selectedBlocks, setSelectedBlocks] = useState<string[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [message, setMessage] = useState('');
  const [points, setPoints] = useState(0);

  const handleDragStart = (e: React.DragEvent, blockId: string) => {
    e.dataTransfer.setData('blockId', blockId);
    setIsDragging(true);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const blockId = e.dataTransfer.getData('blockId');
    if (!selectedBlocks.includes(blockId)) {
      setSelectedBlocks([...selectedBlocks, blockId]);
    }
    setIsDragging(false);
  };

  const handleCheck = () => {
    const level = LEVELS[currentLevel];
    const isCorrect = JSON.stringify(selectedBlocks) === JSON.stringify(level.solution);
    
    if (isCorrect) {
      setMessage('🎉 Great job! You solved it!');
      setPoints(prev => prev + 100);
      setTimeout(() => {
        if (currentLevel < LEVELS.length - 1) {
          setCurrentLevel(prev => prev + 1);
          setSelectedBlocks([]);
          setMessage('');
        } else {
          setMessage('🏆 Congratulations! You completed all levels!');
        }
      }, 2000);
    } else {
      setMessage('Try again! The blocks are not in the correct order.');
    }
  };

  const level = LEVELS[currentLevel];

  return (
    <div className="game-card">
      <div className="flex items-center gap-2 mb-6">
        <Puzzle className="w-6 h-6 text-purple-400" />
        <h2 className="text-xl font-bold text-purple-400">Code Blocks Game</h2>
        <div className="ml-auto flex items-center gap-2">
          <Trophy className="w-5 h-5 text-yellow-400" />
          <span className="text-yellow-400 font-bold">{points} pts</span>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-medium mb-2">{level.title}</h3>
        <p className="text-gray-400">{level.description}</p>
      </div>

      <div 
        className={`drop-zone mb-6 min-h-[100px] flex flex-wrap gap-2 ${isDragging ? 'active' : ''}`}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
      >
        {selectedBlocks.map((blockId) => {
          const block = level.blocks.find(b => b.id === blockId);
          return (
            <div key={blockId} className="code-block">
              {block?.text}
            </div>
          );
        })}
        {selectedBlocks.length === 0 && (
          <div className="text-gray-500 text-center w-full mt-4">
            Drag and drop code blocks here
          </div>
        )}
      </div>

      <div className="mb-6">
        <h4 className="text-sm font-medium text-gray-400 mb-2">Available Blocks:</h4>
        <div className="flex flex-wrap gap-2">
          {level.blocks.map((block) => (
            !selectedBlocks.includes(block.id) && (
              <div
                key={block.id}
                className="code-block"
                draggable
                onDragStart={(e) => handleDragStart(e, block.id)}
              >
                {block.text}
              </div>
            )
          ))}
        </div>
      </div>

      {message && (
        <div className={`p-3 rounded-lg mb-4 ${
          message.includes('Great') || message.includes('Congratulations')
            ? 'bg-green-900/50 text-green-400'
            : 'bg-red-900/50 text-red-400'
        }`}>
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            <span>{message}</span>
          </div>
        </div>
      )}

      <div className="flex justify-between">
        <Button
          onClick={() => {
            setSelectedBlocks([]);
            setMessage('');
          }}
          className="bg-gray-700"
        >
          Reset
        </Button>
        <Button onClick={handleCheck}>
          Check Solution
        </Button>
      </div>
    </div>
  );
}