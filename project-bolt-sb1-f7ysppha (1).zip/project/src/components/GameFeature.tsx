import React, { useState } from 'react';
import { Trophy, Star, Gamepad2, Award, AlertCircle } from 'lucide-react';
import { INITIAL_ACHIEVEMENTS } from '../constants/achievements';
import { CODING_CHALLENGES } from '../constants/challenges';
import { Button } from './ui/Button';
import { CodeEditor } from './CodeEditor';
import { validatePythonSolution } from '../utils/validator';

export function GameFeature() {
  const [achievements, setAchievements] = useState(INITIAL_ACHIEVEMENTS);
  const [challenges, setChallenges] = useState(CODING_CHALLENGES);
  const [selectedChallenge, setSelectedChallenge] = useState(challenges[0]);
  const [userCode, setUserCode] = useState(selectedChallenge.initialCode);
  const [points, setPoints] = useState(0);
  const [feedback, setFeedback] = useState('');

  const handleSubmitSolution = () => {
    const challenge = challenges.find(c => c.id === selectedChallenge.id);
    if (!challenge || challenge.completed) return;

    const validationResult = validatePythonSolution(userCode, selectedChallenge.expectedOutput);
    setFeedback(validationResult.message);

    if (validationResult.isValid) {
      setChallenges(prev => 
        prev.map(c => c.id === challenge.id ? { ...c, completed: true } : c)
      );
      setPoints(prev => prev + challenge.points);
      
      // Unlock achievements
      setAchievements(prev => {
        const newAchievements = [...prev];
        // Unlock Loop Master achievement for the first challenge
        if (challenge.id === 'challenge1') {
          newAchievements[1] = { ...newAchievements[1], unlocked: true };
        }
        // Unlock Challenge Master if all completed
        if (challenges.every(c => c.completed || c.id === challenge.id)) {
          newAchievements[3] = { ...newAchievements[3], unlocked: true };
        }
        return newAchievements;
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-gray-800/50 rounded-lg p-4 backdrop-blur-sm border border-gray-700">
        <div className="flex items-center gap-2 mb-4">
          <Gamepad2 className="w-5 h-5 text-purple-400" />
          <h2 className="text-lg font-semibold text-purple-400">Code Challenges</h2>
          <div className="ml-auto flex items-center gap-2">
            <Award className="w-5 h-5 text-yellow-400" />
            <span className="text-yellow-400 font-bold">{points} pts</span>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex gap-2">
            {challenges.map((challenge) => (
              <Button
                key={challenge.id}
                onClick={() => {
                  setSelectedChallenge(challenge);
                  setUserCode(challenge.initialCode);
                  setFeedback('');
                }}
                className={`${
                  selectedChallenge.id === challenge.id
                    ? 'border-purple-400'
                    : 'border-gray-600'
                } ${challenge.completed ? 'bg-green-600' : ''}`}
              >
                {challenge.title}
              </Button>
            ))}
          </div>

          <div className="bg-gray-900/50 p-4 rounded-lg">
            <h3 className="text-lg font-medium mb-2">{selectedChallenge.description}</h3>
            <div className="mb-4">
              <h4 className="text-sm font-medium text-gray-400 mb-2">Expected Output Format:</h4>
              <pre className="bg-gray-800/50 p-2 rounded text-sm text-gray-300">
                {selectedChallenge.expectedOutput}
              </pre>
            </div>
            <CodeEditor
              code={userCode}
              onChange={(value) => {
                setUserCode(value);
                setFeedback('');
              }}
              label="Your Solution"
            />
            {feedback && (
              <div className={`mt-2 p-2 rounded ${
                feedback.includes('Correct') ? 'bg-green-900/50' : 'bg-red-900/50'
              }`}>
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  <span>{feedback}</span>
                </div>
              </div>
            )}
            <Button
              onClick={handleSubmitSolution}
              disabled={selectedChallenge.completed}
              className="mt-4"
            >
              Submit Solution
            </Button>
          </div>
        </div>
      </div>

      <div className="bg-gray-800/50 rounded-lg p-4 backdrop-blur-sm border border-gray-700">
        <div className="flex items-center gap-2 mb-4">
          <Trophy className="w-5 h-5 text-yellow-400" />
          <h2 className="text-lg font-semibold text-yellow-400">Achievements</h2>
        </div>

        <div className="space-y-4">
          {achievements.map((achievement) => (
            <div
              key={achievement.id}
              className={`p-4 rounded-lg border ${
                achievement.unlocked
                  ? 'border-yellow-400 neon-border'
                  : 'border-gray-700'
              }`}
            >
              <div className="flex items-center gap-2">
                <Star
                  className={`w-4 h-4 ${
                    achievement.unlocked ? 'text-yellow-400' : 'text-gray-500'
                  }`}
                />
                <h3 className="font-medium">{achievement.name}</h3>
              </div>
              <p className="mt-1 text-sm text-gray-400">{achievement.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}