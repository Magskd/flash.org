import React from 'react';
import { BookOpen } from 'lucide-react';

const examples = [
  {
    name: 'Basic Loop Optimization',
    code: `# Original inefficient code
numbers = []
for i in range(1000):
    if i % 2 == 0:
        numbers.append(i)
result = sum(numbers)`,
  },
  {
    name: 'List Comprehension Example',
    code: `# Complex data processing
data = [1, 2, 3, 4, 5]
processed = []
for item in data:
    if item > 2:
        temp = item * 2
        if temp % 2 == 0:
            processed.append(temp)`,
  },
  {
    name: 'Function Optimization',
    code: `def fibonacci(n):
    if n <= 0:
        return []
    elif n == 1:
        return [0]
    elif n == 2:
        return [0, 1]
    
    fib = [0, 1]
    for i in range(2, n):
        fib.append(fib[i-1] + fib[i-2])
    return fib`,
  },
];

interface ExampleCodeProps {
  onSelect: (code: string) => void;
}

export function ExampleCode({ onSelect }: ExampleCodeProps) {
  return (
    <div className="w-full">
      <div className="flex items-center gap-2 mb-4">
        <BookOpen className="w-5 h-5 text-gray-600" />
        <h2 className="text-lg font-semibold text-gray-700">Example Code</h2>
      </div>
      <div className="grid gap-4">
        {examples.map((example) => (
          <button
            key={example.name}
            onClick={() => onSelect(example.code)}
            className="text-left p-4 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <h3 className="font-medium text-gray-900 mb-2">{example.name}</h3>
            <pre className="text-sm text-gray-600 overflow-hidden line-clamp-3">
              {example.code}
            </pre>
          </button>
        ))}
      </div>
    </div>
  );
}