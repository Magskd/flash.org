export const PREDEFINED_QUESTIONS = [
  "How do I optimize a for loop?",
  "What's list comprehension?",
  "How can I improve my code's performance?",
  "What are common Python optimization patterns?",
];

export const BOT_RESPONSES: Record<string, string> = {
  "How do I optimize a for loop?": "For loops can often be optimized using list comprehensions or generator expressions. They're more concise and usually faster.",
  "What's list comprehension?": "List comprehension is a concise way to create lists in Python. Instead of using a for loop with .append(), you can write [x for x in range(10)].",
  "How can I improve my code's performance?": "Use built-in functions, avoid unnecessary loops, use appropriate data structures, and consider using list comprehensions or generator expressions.",
  "What are common Python optimization patterns?": "Common patterns include using list comprehensions, generator expressions, built-in functions, and appropriate data structures like sets for lookups.",
};