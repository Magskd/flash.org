import { Achievement } from '../types';

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: '1',
    name: 'Code Optimizer',
    description: 'Optimize your first piece of code',
    unlocked: false,
  },
  {
    id: '2',
    name: 'Loop Master',
    description: 'Convert a loop to list comprehension',
    unlocked: false,
  },
  {
    id: '3',
    name: 'Chat Champion',
    description: 'Ask 3 questions to the chatbot',
    unlocked: false,
  },
  {
    id: '4',
    name: 'Challenge Master',
    description: 'Complete all coding challenges',
    unlocked: false,
  },
];