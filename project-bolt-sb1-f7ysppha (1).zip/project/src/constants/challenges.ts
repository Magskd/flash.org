export const CODING_CHALLENGES = [
  {
    id: 'challenge1',
    title: 'Loop Optimization',
    description: 'Optimize this loop to use list comprehension',
    initialCode: `numbers = []
for i in range(10):
    if i % 2 == 0:
        numbers.append(i)`,
    expectedOutput: 'numbers = [i for i in range(10) if i % 2 == 0]',
    points: 100,
    completed: false,
  },
  {
    id: 'challenge2',
    title: 'Function Refactoring',
    description: 'Optimize this function to be more concise',
    initialCode: `def get_squares(numbers):
    result = []
    for num in numbers:
        if num > 0:
            result.append(num * num)
    return result`,
    expectedOutput: 'def get_squares(numbers):\n    return [num * num for num in numbers if num > 0]',
    points: 150,
    completed: false,
  },
];